package com.cg.project.exceptions;

public class UserDetailsNotFoundException extends Exception{
	
	public UserDetailsNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}
}