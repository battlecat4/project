package com.cg.project.services;

import com.cg.project.beans.User;
import com.cg.project.exceptions.UserDetailsNotFoundException;

public interface AccountServices {
	User openAccount(User user);
	User getAccountDetails(String emailId) throws UserDetailsNotFoundException;
}
